// Questão 5: Compila ou Não Compila?
// Qual das opções abaixo compila corretamente em Dart?

// Todas as opções compilam corretamente.

// a)
void main() {
  int numero = 10;
  if (numero % 2 == 0) {
  print("Par");
  } else {
  print("Ímpar");
  }
}


// b)

// void main() {
//   for (int i = 0; i < 5; i++) {
//   print(i);
//   }
// }


// c)

// void main() {
//   String nome = "Dart";
//   print("Olá, $nome!");
// }


// d)

// void main() {
//   double altura = 1.75;
//   double peso = 70;
//   double imc = peso / (altura * altura);
//   print("Seu IMC é: $imc");
// }